from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
from datetime import datetime, date
from functools import wraps

app = Flask(__name__)
app.secret_key = "change-this-secret"
DB = "leave_register.db"

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init():
    c = db()
    c.execute("""CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY, username TEXT UNIQUE, password TEXT, role TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS employees(
        id INTEGER PRIMARY KEY, employee_id TEXT UNIQUE, name TEXT, phone TEXT,
        department TEXT, designation TEXT, joining_date TEXT,
        casual REAL DEFAULT 12, sick REAL DEFAULT 12, other REAL DEFAULT 0,
        password TEXT, active INTEGER DEFAULT 1)""")
    c.execute("""CREATE TABLE IF NOT EXISTS leaves(
        id INTEGER PRIMARY KEY, employee_id INTEGER, leave_type TEXT,
        from_date TEXT, to_date TEXT, days REAL, reason TEXT,
        status TEXT DEFAULT 'Pending', applied_at TEXT)""")
    if not c.execute("SELECT 1 FROM users WHERE username='admin'").fetchone():
        c.execute("INSERT INTO users(username,password,role) VALUES(?,?,?)",
                  ("admin", generate_password_hash("admin123"), "admin"))
    c.commit(); c.close()

def admin(f):
    @wraps(f)
    def w(*a, **k):
        return f(*a, **k) if session.get("role")=="admin" else redirect(url_for("login"))
    return w

def employee(f):
    @wraps(f)
    def w(*a, **k):
        return f(*a, **k) if session.get("role")=="employee" else redirect(url_for("login"))
    return w

@app.route("/", methods=["GET"])
def home():
    return redirect(url_for("dashboard" if session.get("role")=="admin" else
                            "employee_dashboard" if session.get("role")=="employee" else "login"))

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method=="POST":
        u,p=request.form["username"].strip(),request.form["password"]
        c=db()
        a=c.execute("SELECT * FROM users WHERE username=?",(u,)).fetchone()
        if a and check_password_hash(a["password"],p):
            session.clear(); session["role"]="admin"; session["uid"]=a["id"]; c.close()
            return redirect(url_for("dashboard"))
        e=c.execute("SELECT * FROM employees WHERE employee_id=? AND active=1",(u,)).fetchone()
        c.close()
        if e and check_password_hash(e["password"],p):
            session.clear(); session["role"]="employee"; session["eid"]=e["id"]
            return redirect(url_for("employee_dashboard"))
        flash("Invalid login details")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear(); return redirect(url_for("login"))

@app.route("/dashboard")
@admin
def dashboard():
    c=db(); month=datetime.now().strftime("%Y-%m"); today=date.today().isoformat()
    stats=[
        c.execute("SELECT COUNT(*) FROM employees WHERE active=1").fetchone()[0],
        c.execute("SELECT COUNT(*) FROM leaves WHERE status='Pending'").fetchone()[0],
        c.execute("SELECT COALESCE(SUM(days),0) FROM leaves WHERE status='Approved' AND substr(from_date,1,7)=?",(month,)).fetchone()[0],
        c.execute("SELECT COUNT(DISTINCT employee_id) FROM leaves WHERE status='Approved' AND from_date<=? AND to_date>=?",(today,today)).fetchone()[0]]
    recent=c.execute("""SELECT l.*,e.employee_id code,e.name FROM leaves l JOIN employees e ON e.id=l.employee_id
                        ORDER BY l.applied_at DESC LIMIT 6""").fetchall()
    c.close(); return render_template("dashboard.html",stats=stats,recent=recent)

@app.route("/employees")
@admin
def employees():
    c=db(); rows=c.execute("SELECT * FROM employees ORDER BY name").fetchall(); c.close()
    return render_template("employees.html",employees=rows)

@app.route("/employees/add",methods=["GET","POST"])
@admin
def add_employee():
    if request.method=="POST":
        f=request.form
        c=db()
        try:
            c.execute("""INSERT INTO employees(employee_id,name,phone,department,designation,joining_date,casual,sick,other,password)
                      VALUES(?,?,?,?,?,?,?,?,?,?)""",(f["employee_id"],f["name"],f["phone"],f.get("department",""),
                      f.get("designation",""),f.get("joining_date",""),f.get("casual",12),f.get("sick",12),f.get("other",0),
                      generate_password_hash(f["password"])))
            c.commit(); flash("Employee added successfully")
        except sqlite3.IntegrityError: flash("Employee ID already exists")
        c.close(); return redirect(url_for("employees"))
    return render_template("add_employee.html")

@app.route("/requests")
@admin
def requests():
    c=db(); rows=c.execute("""SELECT l.*,e.employee_id code,e.name FROM leaves l JOIN employees e ON e.id=l.employee_id
                             ORDER BY l.applied_at DESC""").fetchall(); c.close()
    return render_template("requests.html",rows=rows)

@app.route("/leave/<int:lid>/<action>")
@admin
def leave_action(lid,action):
    c=db(); l=c.execute("SELECT * FROM leaves WHERE id=?",(lid,)).fetchone()
    if not l or l["status"]!="Pending": c.close(); return redirect(url_for("requests"))
    if action=="approve":
        e=c.execute("SELECT * FROM employees WHERE id=?",(l["employee_id"],)).fetchone()
        col={"Casual":"casual","Sick":"sick","Other":"other"}[l["leave_type"]]
        if e[col] < l["days"]: flash("Not enough leave balance"); c.close(); return redirect(url_for("requests"))
        c.execute(f"UPDATE employees SET {col}={col}-? WHERE id=?",(l["days"],e["id"]))
        c.execute("UPDATE leaves SET status='Approved' WHERE id=?",(lid,)); flash("Leave approved")
    else:
        c.execute("UPDATE leaves SET status='Rejected' WHERE id=?",(lid,)); flash("Leave rejected")
    c.commit(); c.close(); return redirect(url_for("requests"))

@app.route("/register")
@admin
def register():
    month=request.args.get("month",datetime.now().strftime("%Y-%m"))
    c=db()
    rows=c.execute("""SELECT e.employee_id code,e.name,e.department,l.leave_type,l.from_date,l.to_date,l.days,l.reason
                      FROM leaves l JOIN employees e ON e.id=l.employee_id
                      WHERE l.status='Approved' AND substr(l.from_date,1,7)=?
                      ORDER BY l.from_date DESC""",(month,)).fetchall()
    c.close(); return render_template("register.html",rows=rows,month=month)

@app.route("/report")
@admin
def report():
    month=request.args.get("month",datetime.now().strftime("%Y-%m")); c=db()
    rows=c.execute("""SELECT e.employee_id code,e.name,
        COALESCE(SUM(CASE WHEN l.leave_type='Casual' THEN l.days ELSE 0 END),0) casual,
        COALESCE(SUM(CASE WHEN l.leave_type='Sick' THEN l.days ELSE 0 END),0) sick,
        COALESCE(SUM(CASE WHEN l.leave_type='Other' THEN l.days ELSE 0 END),0) other,
        COALESCE(SUM(l.days),0) total
        FROM employees e LEFT JOIN leaves l ON e.id=l.employee_id AND l.status='Approved'
        AND substr(l.from_date,1,7)=? WHERE e.active=1 GROUP BY e.id ORDER BY total DESC""",(month,)).fetchall()
    c.close(); return render_template("report.html",rows=rows,month=month)

@app.route("/employee")
@employee
def employee_dashboard():
    c=db(); e=c.execute("SELECT * FROM employees WHERE id=?",(session["eid"],)).fetchone()
    total=c.execute("SELECT COALESCE(SUM(days),0) FROM leaves WHERE employee_id=? AND status='Approved' AND substr(from_date,1,7)=?",
                    (e["id"],datetime.now().strftime("%Y-%m"))).fetchone()[0]
    c.close(); return render_template("employee.html",e=e,total=total)

@app.route("/apply",methods=["GET","POST"])
@employee
def apply():
    if request.method=="POST":
        f=request.form; start=datetime.strptime(f["from_date"],"%Y-%m-%d"); end=datetime.strptime(f["to_date"],"%Y-%m-%d")
        if end<start: flash("Invalid dates"); return redirect(url_for("apply"))
        days=(end-start).days+1; c=db(); e=c.execute("SELECT * FROM employees WHERE id=?",(session["eid"],)).fetchone()
        col={"Casual":"casual","Sick":"sick","Other":"other"}[f["leave_type"]]
        if e[col]<days: flash("Not enough leave balance"); c.close(); return redirect(url_for("apply"))
        c.execute("""INSERT INTO leaves(employee_id,leave_type,from_date,to_date,days,reason,applied_at)
                     VALUES(?,?,?,?,?,?,?)""",(e["id"],f["leave_type"],f["from_date"],f["to_date"],days,f["reason"],datetime.now().isoformat()))
        c.commit(); c.close(); flash("Leave request submitted"); return redirect(url_for("employee_dashboard"))
    return render_template("apply.html")

@app.route("/my-leaves")
@employee
def my_leaves():
    c=db(); rows=c.execute("SELECT * FROM leaves WHERE employee_id=? ORDER BY applied_at DESC",(session["eid"],)).fetchall(); c.close()
    return render_template("my_leaves.html",rows=rows)

init()
app.run(host="0.0.0.0",port=5000)
